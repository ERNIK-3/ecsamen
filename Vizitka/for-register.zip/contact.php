<div>
            <p></p>
            <form action="script/send.php" method="post">
                <label>
                    Введите имя
                    <input name="name" type="text" placeholder="Ваше имя">
                </label><br><br>
                <input name="email" type="email">

                <textarea name="message"  rows="5" cols="33"  placeholder="Что будем искать?" required></textarea><br>
                <input name="file" type="file">
                <br><br><br><button type="submit">И так можно отправить</button>
            </form>
        </div>
        <div></div>
        <div></div>