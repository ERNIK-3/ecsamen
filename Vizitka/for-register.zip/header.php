<!DOCTYPE html>
<html lang="ru"  id = "html">
    <head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.rtl.min.css" integrity="sha384-q8+l9TmX3RaSz3HKGBmqP2u5MkgeN7HrfOJBLcTgZsQsbrx8WqqxdA5PuwUV9WIx" crossorigin="anonymous">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="styles.css">
        <title>Circle - Free HTML Template</title>
    </head>
<body>
    <div class="sidebar">
        <img src="img/cat.webp" alt="">
        <h1>Вартеванян Эрик Каренович</h1>
        <nav>
            <ul>
                <b>
                <li><a href="#">Главная</a></li>
                <li><a href="obomne.php">Обо мне</a></li>
                <li><a href="contact.php">Контакты</a></li>
                <li><a href="masseng.php">Сообщение</a></li>
                <li><a href="Markup.html">Регисстрация</a></li>
                </b>
            </ul>
        </nav>
    </div>