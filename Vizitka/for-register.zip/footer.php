</div>
<footer>
    <p>
        <span>Все права 2025 год</span>
    </p>
</footer>
    <div class="modalBackground">
        <div class="modalActive">
            <div class="modalClose">
                <img src="img/pl.png" />
            </div>
            <div class="modalWindow">
                <p>Есть супер предложение!!!</p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</body>
</html>